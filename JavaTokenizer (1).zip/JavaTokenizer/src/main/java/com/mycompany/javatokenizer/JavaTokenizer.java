/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javatokenizer;

import java.io.IOException;

/**
 *
 * @author jakes
 */
public class JavaTokenizer {

    public static void main(String[] args) throws IOException {
        MultiLangTokenizer.tokenize("Test.c");
    }
}
