/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javatokenizer;

import org.antlr.v4.runtime.*;
import java.io.IOException;

public class MultiLangTokenizer {

    public static void tokenize(String filePath) throws IOException {
        CharStream input = CharStreams.fromFileName(filePath);

        Lexer lexer;

        if (filePath.endsWith(".java")) {
            lexer = new JavaLexer(input);
        } 
        else if (filePath.endsWith(".c")) {
            lexer = new CLexer(input);
        } 
        else if (filePath.endsWith(".cpp")) {
            lexer = new CPP14Lexer(input);
        } 
        else {
            throw new IllegalArgumentException("Unsupported file type");
        }

        Token token;
        while ((token = lexer.nextToken()).getType() != Token.EOF) {
    if (token.getChannel() == Token.DEFAULT_CHANNEL) {

        String tokenName = lexer.getVocabulary().getSymbolicName(token.getType());

        int line = token.getLine();
        int column = token.getCharPositionInLine();

        System.out.println(
            "Line " + line +
            ", Column " + column +
            " -> " + tokenName +
            " : " + token.getText()
        );
    }
        }
    }


    public static void main(String[] args) throws IOException {
        tokenize("Test.java"); // change to Test.c or Test.cpp to test others
    }
}
