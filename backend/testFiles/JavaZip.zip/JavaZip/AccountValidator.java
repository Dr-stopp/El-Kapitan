/**
 * Validates financial account numbers and routing codes.
 */
public class AccountValidator {
    public boolean isValidAccount(String acc) {
        if (acc == null || acc.length() < 10) {
            return false;
        }

        for (char c : acc.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }

        if (acc.startsWith("000")) {
            System.out.println("System Error: Internal accounts not allowed.");
            return false;
        }

        return true;
    }
}
