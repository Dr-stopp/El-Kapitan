import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Custom logging utility for system-wide event tracking.
 */
public class AppLogger {
    private static final DateTimeFormatter dtf =
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    public void logInfo(String message) {
        printLog("INFO", message);
    }

    public void logError(String message, Exception e) {
        printLog("ERROR", message + " | Trace: " + e.getMessage());
    }

    private void printLog(String level, String msg) {
        String now = dtf.format(LocalDateTime.now());
        System.out.println("[" + now + "] [" + level + "] " + msg);
    }
}
