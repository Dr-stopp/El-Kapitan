import java.util.regex.Pattern;

/**
 * Utility for validating security credentials and input formats.
 */
public class AuthValidator {
    private static final String EMAIL_REGEX = "^(.+)@(.+)$";
    private static final String PASS_REGEX = "^(?=.*[0-9])(?=.*[a-z]).{8,}$";

    public boolean isEmailValid(String email) {
        if (email == null || email.isEmpty()) return false;
        return Pattern.compile(EMAIL_REGEX).matcher(email).matches();
    }

    public boolean isPasswordStrong(String password) {
        if (password == null) return false;
        boolean matches = Pattern.compile(PASS_REGEX).matcher(password).matches();
        if (!matches) {
            System.out.println("Security Warning: Password does not meet complexity requirements.");
        }
        return matches;
    }
}
