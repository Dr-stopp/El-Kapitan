import java.util.*;

/**
 * A generic data store for managing collections of different types.
 */
public class GenericRepository<T> {
    private List<T> items = new ArrayList<>();

    public void add(T item) {
        items.add(item);
    }

    public T findByIndex(int index) {
        if (index >= 0 && index < items.size()) {
            return items.get(index);
        }
        return null;
    }

    public int count() {
        return items.size();
    }

    public void clear() {
        items.clear();
        System.out.println("Repository has been reset.");
    }
}
