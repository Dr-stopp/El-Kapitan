import java.util.*;
import java.util.function.Predicate;

/**
 * Demonstrates high-order functions using Predicate interfaces.
 */
public class LambdaFilter {
    public List<Integer> applyFilter(List<Integer> numbers, Predicate<Integer> tester) {
        List<Integer> result = new ArrayList<>();
        for (Integer n : numbers) {
            if (tester.test(n)) {
                result.add(n);
            }
        }
        return result;
    }

    public void runDemo() {
        List<Integer> data = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        List<Integer> evens = applyFilter(data, n -> n % 2 == 0);
        System.out.println("Filtered Evens: " + evens);
    }
}
