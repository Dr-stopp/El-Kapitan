import java.io.File;
import java.nio.file.*;

/**
 * Prepares file lists for archival processes.
 */
public class FileArchiveTask {
    public void scanDirectory(String path) {
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();

        if (listOfFiles == null) {
            System.out.println("Directory is empty or invalid.");
            return;
        }

        for (File file : listOfFiles) {
            if (file.isFile()) {
                System.out.println("Found File: " + file.getName()
                        + " (" + file.length() + " bytes)");
            } else if (file.isDirectory()) {
                System.out.println("Found Directory: " + file.getName());
            }
        }
    }

    public String getFileExtension(String fileName) {
        int i = fileName.lastIndexOf('.');
        return (i > 0) ? fileName.substring(i + 1) : "no extension";
    }
}
