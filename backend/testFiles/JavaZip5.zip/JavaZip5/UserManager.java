import java.util.*;

/**
 * Manages user registration and authentication logic.
 */
public class UserManager {
    private List<String> database = new ArrayList<>();

    public boolean registerUser(String username, String password) {
        if (username == null || username.length() < 3) {
            System.err.println("Invalid username length.");
            return false;
        }
        if (database.contains(username)) {
            System.err.println("User already exists in system.");
            return false;
        }
        database.add(username);
        System.out.println("User " + username + " successfully registered.");
        return true;
    }

    public void listAllUsers() {
        System.out.println("Total Users: " + database.size());
        database.forEach(u -> System.out.println("- " + u));
    }
}