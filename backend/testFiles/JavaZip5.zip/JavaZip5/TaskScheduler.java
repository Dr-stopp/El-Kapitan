/**
 * Simulates the scheduling and execution of background tasks.
 */
public class TaskScheduler {
    private String taskName;
    private boolean isRunning = false;

    public TaskScheduler(String name) {
        this.taskName = name;
    }

    public void execute() {
        if (isRunning) {
            System.out.println("Task " + taskName + " is already in progress.");
            return;
        }
        isRunning = true;
        System.out.println("Starting execution of: " + taskName);
        try {
            Thread.sleep(1000); // Simulate work
        } catch (InterruptedException e) {
            System.err.println("Task interrupted: " + e.getMessage());
        }
        isRunning = false;
        System.out.println("Task " + taskName + " completed successfully.");
    }
}
