/**
 * Handles conversions between Celsius, Fahrenheit, and Kelvin.
 */
public class TemperatureConverter {
    public double celsiusToFahrenheit(double c) {
        return (c * 9/5) + 32;
    }

    public double fahrenheitToCelsius(double f) {
        return (f - 32) * 5/9;
    }

    public double celsiusToKelvin(double c) {
        return c + 273.15;
    }

    public void displayConversionTable(double startC, double endC) {
        System.out.println("Celsius\tFahrenheit\tKelvin");
        for (double i = startC; i <= endC; i += 5) {
            System.out.printf("%.1f\t%.1f\t\t%.1f%n", i, celsiusToFahrenheit(i), celsiusToKelvin(i));
        }
    }
}
