import java.util.HashMap;
import java.util.Map;

/**
 * Tracks stock levels and identifies items needing restock.
 */
public class InventoryTracker {
    private Map<String, Integer> stock = new HashMap<>();
    private final int LOW_STOCK_THRESHOLD = 5;

    public void updateStock(String item, int count) {
        stock.put(item, stock.getOrDefault(item, 0) + count);
        System.out.println("Updated " + item + ": New total is " + stock.get(item));
    }

    public void checkLowStock() {
        System.out.println("--- Low Stock Alert ---");
        for (Map.Entry<String, Integer> entry : stock.entrySet()) {
            if (entry.getValue() < LOW_STOCK_THRESHOLD) {
                System.out.println("ALERT: " + entry.getKey() + " is low (" + entry.getValue() + ")");
            }
        }
    }

    public void removeProduct(String item) {
        if (stock.containsKey(item)) {
            stock.remove(item);
            System.out.println(item + " removed from inventory.");
        }
    }
}
