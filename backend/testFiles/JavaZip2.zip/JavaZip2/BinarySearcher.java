/**
 * Implements a recursive binary search on a sorted integer array.
 */
public class BinarySearcher {
    public int search(int[] arr, int left, int right, int x) {
        if (right >= left) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == x) return mid;

            if (arr[mid] > x) {
                return search(arr, left, mid - 1, x);
            }

            return search(arr, mid + 1, right, x);
        }
        return -1;
    }

    public void displayResult(int result) {
        if (result == -1) {
            System.out.println("Element is not present in the array.");
        } else {
            System.out.println("Element found at index: " + result);
        }
    }
}