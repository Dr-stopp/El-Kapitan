import java.util.Date;

/**
 * Abstract base for generating system reports.
 */
public abstract class BaseReport {
    protected String reportId;
    protected Date generatedAt;

    public BaseReport(String id) {
        this.reportId = id;
        this.generatedAt = new Date();
    }

    public abstract void generateContent();

    public void printHeader() {
        System.out.println("Report ID: " + reportId);
        System.out.println("Timestamp: " + generatedAt.toString());
        System.out.println("----------------------------");
    }
}
