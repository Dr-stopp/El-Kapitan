/**
 * Calculates area and perimeter for various 2D shapes.
 */
public class ShapeCalculator {
    public static final double PI = 3.141592653589793;

    public double circleArea(double radius) {
        return PI * Math.pow(radius, 2);
    }

    public double rectangleArea(double length, double width) {
        return length * width;
    }

    public double triangleArea(double base, double height) {
        return 0.5 * base * height;
    }

    public void printCircleStats(double r) {
        double area = circleArea(r);
        double circ = 2 * PI * r;
        System.out.printf("Radius: %.2f | Area: %.2f | Circumference: %.2f%n", r, area, circ);
    }
}
