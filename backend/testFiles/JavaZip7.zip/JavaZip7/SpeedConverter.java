/**
 * Utility for converting between metric and imperial speed units.
 */
public class SpeedConverter {
    private static final double KPH_TO_MPH = 0.621371;
    private static final double MPH_TO_KPH = 1.60934;

    public double toMilesPerHour(double kph) {
        return kph * KPH_TO_MPH;
    }

    public double toKilometersPerHour(double mph) {
        return mph * MPH_TO_KPH;
    }

    public void printSpeedLimit(double speedKph) {
        double mph = toMilesPerHour(speedKph);
        System.out.printf("Limit: %.1f km/h is roughly %.1f mph%n", speedKph, mph);
    }
}
