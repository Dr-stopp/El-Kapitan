import java.util.LinkedList;
import java.util.Queue;

/**
 * Manages a thread-safe-style queue for processing tokens.
 */
public class TakenQueue {
    private Queue<String> tokens = new LinkedList<>();

    public void pushToken(String t) {
        if (t != null && !t.isBlank()) {
            tokens.add(t);
        }
    }

    public String nextToken() {
        return tokens.isEmpty() ? "END_OF_STREAM" : tokens.poll();
    }

    public void clearAll() {
        System.out.println("Purging " + tokens.size() + " tokens.");
        tokens.clear();
    }
}
