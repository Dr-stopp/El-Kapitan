/**
 * Utility to check JVM memory and available processor cores.
 */
public class SystemMonitor {
    public void printMemoryStats() {
        Runtime rt = Runtime.getRuntime();
        long total = rt.totalMemory() / (1024 * 1024);
        long free = rt.freeMemory() / (1024 * 1024);

        System.out.println("--- JVM Statistics ---");
        System.out.println("Total Memory: " + total + " MB");
        System.out.println("Used Memory: " + (total - free) + " MB");
    }

    public int getCores() {
        return Runtime.getRuntime().availableProcessors();
    }
}
